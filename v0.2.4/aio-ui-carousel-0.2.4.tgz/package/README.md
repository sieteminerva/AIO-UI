# Carousel (`@aio-ui/carousel`)

Carousel turns an array of slides into a track plus controls and navigation dots, with four
transitions (`fade`, `slide-left`, `slide-right`, `slide-up`, `slide-down`) and optional autoplay.

It owns a timer, so `unmount()` matters: it clears the interval and the button/dot handlers, and
`prepare()` calls it first so re-rendering the same instance never doubles a timer.

**The builder is an element factory.** It assembles the markup below, and `Carousel.css` only
targets those classes and tokens. The CSS therefore behaves like a plain CSS library: the same
nesting and class names written by hand are styled identically. Customise it by overriding a
selector, or retheme it without touching markup by redeclaring a `--app-*` token on an ancestor
(or one `--carousel-*` token for this component only).

<!-- install:begin -->
## Install

    npm install https://github.com/sieteminerva/AIO-UI/raw/releases/v0.2.4/aio-ui-carousel-0.2.4.tgz

CDN (ES module, no build step) — `https://cdn.jsdelivr.net/gh/sieteminerva/AIO-UI@v0.2.4/packages/components/carousel/dist/index.js`
Stylesheet — `https://cdn.jsdelivr.net/gh/sieteminerva/AIO-UI@v0.2.4/packages/components/carousel/dist/Carousel.css`
<!-- install:end -->

## Payload

```ts
[
  { image: "a.png", title: "First", desc: "…" },
  { image: "b.png", title: "Second", desc: "…" },
];
```

An array of slides. The same object may carry `attrs` / `config` to override instance options from
data (see `AttrsConfigMap`), which is how spreadsheet-driven content can set a carousel up without a
code change.

## Config

| Option           | Default      | Meaning                                                  |
| ---------------- | ------------ | -------------------------------------------------------- |
| `container`      | `""`         | Selector, element or nothing — where the tree is mounted |
| `showControl`    | `"auto"`     | Prev/next buttons (`true`, `false` or automatic)         |
| `showNavigation` | `true`       | Dot navigation                                           |
| `autoPlay`       | `4000`       | Interval in ms, `true` for the default, `false` off      |
| `loop`           | `true`       | Wrap around at the ends                                  |
| `vertical`       | `false`      | Vertical track (fade becomes `slide-up`)                 |
| `slidesPerView`  | `1`          | Visible slides; >1 turns fade into `slide-left`          |
| `animation`      | `"fade"`     | `fade` or `slide-*`                                      |
| `pauseOnHover`   | `true`       | Pause autoplay while hovered                             |
| `slideWidth`     | `""`         | Inline width for a slide                                 |
| `slideHeight`    | `""`         | Inline height for a slide                                |
| `selectors`      | see defaults | Per-key tag/class override                               |

With `loop: false` a navigation past an edge clamps and **stops autoplay**, so the timer cannot keep
firing at a dead end.

## Nodes

| Key                             | Default tag | Class                     |
| ------------------------------- | ----------- | ------------------------- |
| `@container`                    | `div`       | `carousel-widget-wrapper` |
| `@carousel`                     | `div`       | `carousel`                |
| `@carousel>control`             | `div`       | `control-group`           |
| `@carousel>control>prev`        | `button`    | `control prev`            |
| `@carousel>control>next`        | `button`    | `control next`            |
| `@carousel>navigations`         | `div`       | `navigations`             |
| `@carousel>navigations>dot`     | `button`    | `dot`                     |
| `@carousel>track`               | `div`       | `track`                   |
| `@carousel>track>slide`         | `div`       | `slide`                   |
| `@carousel>track>slide>inner`   | `div`       | `slide-inner`             |
| `@carousel>track>slide>caption` | `div`       | `caption`                 |
| `@carousel>track>slide>title`   | `h3`        | `title`                   |
| `@carousel>track>slide>desc`    | `p`         | `desc`                    |
| `@carousel>track>slide>image`   | `img`       | `img-fluid`               |

### Structure

The root carries the resolved state (`anim-*`, `auto-controls`, `orient-*`); `active` moves with
the index.

```html
<div class="carousel anim-fade auto-controls orient-horizontal" role="region">
  <div class="track">
    <div class="slide active" role="group">
      <div class="slide-inner">
        <img class="img-fluid" src="first.png" alt="" />
        <div class="caption"><h3 class="title">First</h3></div>
      </div>
    </div>
    <div class="slide" role="group">…</div>
  </div>
  <div class="control-group">
    <button class="control prev">‹</button>
    <button class="control next">›</button>
  </div>
  <div class="navigations horizontal-dots" role="group">
    <button class="dot active"></button>
    <button class="dot"></button>
  </div>
</div>
```

## Tokens

One token, declared once on `:root, [data-theme]`. The sheet used to read `--radius-image`, which no
package ships, so the slide corner silently fell back to 8px.

| Token                            | Derives from                | Used for     |
| -------------------------------- | --------------------------- | ------------ |
| `--carousel-image-border-radius` | `--app-image-border-radius` | Media corner |

A payload with no slides renders the empty shell and skips layout — it does not throw.

## Wiring checklist

1. Add `"carousel"` to `iBuilderRegistry` in `packages/core/src/types/registry.ts`.
2. Add a loader for `@aio-ui/carousel` to the host's asset map.
3. Add a `stylesheet` loader for `@aio-ui/carousel/Carousel.css`.
4. List it in the host's route plan: `registerModule(components, [{ route, components: ["carousel"] }])`.
