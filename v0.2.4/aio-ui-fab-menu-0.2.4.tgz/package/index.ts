/** Public surface of `@aio-ui/fab-menu` — curated, never `export *`. */

export { FabMenuBuilder } from "./FabMenu";
export type { FabPosition, iFabMenuConfig } from "./FabMenu";
