import type { iBasicNode, iBuilderConfig, iBuilderRegistry, iContentContract, iElementAnimation } from "@aio-ui/core";
import { Builder } from "@aio-ui/base";
import { Skeleton } from "@aio-ui/skeleton";

export type TabElementType =
  | "@container"
  | "@tab"
  | "@tab>menu"
  | "@tab>menu>item"
  | "@tab>menu>item>label"
  | "@tab>body"
  | "@tab>panel"
  | "@tab>panel>content"
  | "@tab>panel>content>eyebrow"
  | "@tab>panel>content>title"
  | "@tab>panel>content>desc"
  | "@tab>footer"
  | "@tab>spinner";




export interface iTabConfig extends iBuilderConfig<TabElementType> {
  container?: string | HTMLElement | null;
  menuPosition: "top" | "left" | "bottom" | "right";
  /**
   * Look of the strip. `default` is the gradient pill; `folder` lifts the active tab onto
   * the panel along the rule on whichever edge `menuPosition` names; `underline` keeps the
   * labels and grows a rule on the panel-facing edge; `segmented` sits the strip on an inset
   * rail with a lifted active segment.
   */
  appearance: "folder" | "underline" | "segmented" | "default";
  lazyload: boolean;
  name: string;
  minHeight: string;
  /** 💣 Saat `true`, isi panel tab sebelumnya dihancurkan (diganti kosong) begitu pengguna
   *  berpindah ke tab lain — memaksa konten dimuat ulang segar saat kembali ke tab itu. */
  destroyPrevious: boolean;
  /** Tab yang aktif saat render: indeks, id tombol, atau label/judulnya. */
  active: string | number;
  /** `false` mematikan gerak panel, `true` memakai fade bawaan, objek membawa nama
   *  `@keyframes` (lewat `data-animation` dan dua custom property yang dibaca sheet). */
  animation: boolean | iElementAnimation;
}


export type iTabMenuProperty = { label: string; title: string; link?: string; id?: string, className?: string } | iBasicNode;
export type iTabItemContent = { title?: string; eyebrow?: string; description?: string; } | iBasicNode;
export type iTabItemProperty = { id?: string; className?: string; panel: iTabItemContent } | HTMLElement;
export type iTabFooterProperty = { id?: string; className?: string; text: string };

export interface iTabContent {
  menu?: HTMLElement[] | iTabMenuProperty[] | null;
  body: iTabItemProperty[] | HTMLElement[];
  footer?: HTMLElement | iTabFooterProperty | null;
}

export class TabBuilder extends Builder<TabElementType, iTabConfig> {
  builderId: keyof iBuilderRegistry = "tab";
  readonly name: keyof iBuilderRegistry = "tab";
  readonly stylesheet: string = "./Tab.css";
  static readonly contract: iContentContract = {
    schema: {
      t: "record",
      open: true,
      of: {
        menu: {
          t: "list",
          single: true,
          of: {
            t: "record",
            open: true,
            of: {
              label: { t: "string" },
              title: { t: "string" },
              id: { t: "string" },
              className: { t: "string" },
            },
          },
        },
        body: {
          t: "list",
          single: true,
          of: { t: "record", open: true, of: { panel: { t: "any" }, body: { t: "any" } } },
        },
        footer: { t: "any" },
      },
    },
    example: {
      menu: [{ label: "Overview", title: "Overview" }],
      body: [{ panel: { title: "Overview", description: "…" } }],
    },
  };
  // ENKAPSULASI: Menyimpan data body tab secara aman & terisolasi
  #items: iTabItemProperty[] = [];

  /** The menu records of the last `prepare`, kept so a panel can name its own button. */
  #menu: iTabMenuProperty[] = [];

  // STATE MANAGEMENT INTERNAL
  private currentTabIndex = 0;

  /**
   * One id stem per instance.
   *
   * Nested tabs used to share the literal `gen`, so `aria-controls`/`tabpanel-*` ids
   * collided and a nested panel answered to the outer menu. The stem comes from
   * `config.name` (random per instance) and never from the document.
   */
  private readonly uid: string;

  private _listenersTabChanged: ((detail: { index: number; label: string; title: string }) => void)[] = [];
  private _listenersContentLoaded: ((detail: { index: number; element: HTMLElement }) => void)[] = [];
  private _boundKeyDownHandler?: (e: KeyboardEvent) => void;

  /**
   * 🪶 LOADING MOCKUP — the tab bar over an empty panel, drawn with the mandatory
   * `@aio-ui/skeleton` primitive. Tab count stays at three: the panel is what reserves the
   * vertical space, and it is geometry, not data.
   */
  protected loading(): HTMLElement {
    return Skeleton.create({
      shape: "stack",
      children: [
        { shape: "row", gap: "0.5rem", children: [{ shape: "bone", width: "6rem", height: "2.25rem", count: 3 }] },
        { shape: "bone", height: "10rem" },
      ],
    });
  }

  constructor(config: Partial<iTabConfig> = {}) {
    super();

    const defaultTabSelectors = {
      "@container": { tagName: "div", className: "tab-widget-wrapper" },
      "@tab": { tagName: "div", className: "tab" },
      "@tab>menu": { tagName: "div", className: "menu" },
      "@tab>menu>item": { tagName: "button", className: "button" },
      "@tab>menu>item>label": { tagName: "span", className: "btn-label" },
      "@tab>body": { tagName: "div", className: "body" },
      "@tab>panel": { tagName: "div", className: "panel hidden" },
      "@tab>panel>content": { tagName: "div", className: "content" },
      "@tab>panel>content>eyebrow": { tagName: "span", className: "eyebrow" },
      "@tab>panel>content>title": { tagName: "h3", className: "title" },
      "@tab>panel>content>desc": { tagName: "p", className: "desc" },
      "@tab>footer": { tagName: "div", className: "footer" },
      "@tab>spinner": { tagName: "div", className: "spinner hidden" }
    };

    const defaultConfig: Required<iTabConfig> = {
      themeId: "default",
      container: null,
      menuPosition: "top",
      appearance: "default",
      lazyload: true,
      name: "tab-" + Math.random().toString(36).substring(7),
      minHeight: "400px",
      destroyPrevious: false,
      active: 0,
      animation: true,
      selectors: defaultTabSelectors,
      namespace: null,
      emit: () => { }
    };

    this.config = this.resolveConfig(defaultConfig, config);
    this.uid = this.config.name;
  }

  // SETTER PUSAT: Mengamankan data dari manipulasi pihak ketiga
  private set items(newItems: iTabItemProperty[]) {
    if (!Array.isArray(newItems)) {
      console.error("TabBuilder validation failed: Items must be an array.");
      return;
    }
    this.#items = newItems.map(item => {
      if (item instanceof HTMLElement) return item; //<= THE FIX
      return Object.freeze({ ...item })
    });
  }

  /** Local DOM lookup for the tab root. The root's own `id` is stamped by `@tab`; ids that
   *  must not collide with a nested tab come from `uid`, never from the document. */
  // private get footerElement(): HTMLElement | null { return this.load("@tab>footer") as HTMLElement; }

  public prepare(data: any, _config?: Partial<iTabConfig>): HTMLElement {
    if (_config) this.config = this.resolveConfig(this.config, _config);

    const content: iTabContent = data ?? { body: [] };

    this.items = content.body || [];
    this.#menu = content.menu || [];
    this.currentTabIndex = 0;

    return this.render("@tab", content) as HTMLElement;
  }

  protected template(typeKey: TabElementType, el: HTMLElement, payload?: any): void {
    switch (typeKey) {
      case "@tab": {
        // `classList` dedupes: the selector already stamped `tab`, and string concatenation
        // used to emit it twice (`tab position-top tab`).
        el.classList.add("tab");
        el.dataset.menu = this.config.menuPosition;
        // Only a non-default look is stamped: the default markup stays `tab position-top`.
        if (this.config.appearance !== "default") el.dataset.appearance = this.config.appearance;
        this.applyAnimation(el);
        el.style.minHeight = this.config.minHeight;

        if (this.config.container instanceof HTMLElement) {
          el.id = this.config.container.id || el.id;
        }

        const fragment = document.createDocumentFragment();

        const spinner = this.render("@tab>spinner", null);
        if (spinner) fragment.appendChild(spinner);

        let menuElement: HTMLElement | null = null;
        if (payload.menu && Array.isArray(payload.menu)) {
          menuElement = this.render("@tab>menu", payload.menu) as HTMLElement;
        }

        const bodyElement = this.render("@tab>body", this.#items) as HTMLElement;

        let footerElement: HTMLElement | null = null;
        if (payload.footer) {
          footerElement = this.render("@tab>footer", payload.footer) as HTMLElement;
        }

        if (this.config.menuPosition === "bottom") {
          fragment.appendChild(bodyElement);
          if (menuElement) fragment.appendChild(menuElement);
        } else {
          if (menuElement) fragment.appendChild(menuElement);
          fragment.appendChild(bodyElement);
        }

        if (footerElement) {
          fragment.appendChild(footerElement);
        }

        el.appendChild(fragment);
        break;
      }

      case "@tab>menu": {
        el.setAttribute("role", "tablist");
        el.setAttribute("aria-label", "Tab Navigation");

        payload.forEach((meta: any, idx: number) => {
          if (meta instanceof HTMLElement) {
            el.appendChild(meta);
            return;
          }

          const btn = this.render("@tab>menu>item", { meta, idx }) as HTMLElement;
          const isLink = typeof meta === "object" && meta !== null && !!meta.link;

          if (isLink) {
            const a = document.createElement("a");
            a.className = btn.className;
            if (btn.id) a.id = btn.id;
            a.href = meta.link;

            while (btn.firstChild) a.appendChild(btn.firstChild);

            Array.from(btn.attributes).forEach(attr => {
              if (attr.name !== 'class' && attr.name !== 'id') {
                a.setAttribute(attr.name, attr.value);
              }
            });
            a.onclick = btn.onclick;

            el.appendChild(a);
          } else {
            el.appendChild(btn);
          }
        });
        break;
      }

      case "@tab>menu>item": {
        const { meta, idx } = payload;

        el.setAttribute("role", "tab");
        el.setAttribute("aria-selected", "false");
        el.setAttribute("tabindex", "-1");
        // One id pair per index, read through the same helpers the panel uses. A record
        // with its own `id` keeps it; `aria-controls` always names the panel that exists.
        // The old pair (`tabbtn-…` on the button, `tabpanel-…` in the attribute) broke as
        // soon as either side carried an id of its own.
        el.id = this.buttonIdOf(idx);
        el.setAttribute("aria-controls", this.panelIdOf(idx));

        const spanLabel = this.render("@tab>menu>item>label", meta)!;
        el.append(spanLabel);

        if (meta.className) el.classList.add(...meta.className.split(" "));
        // `title` is the tooltip, not a second line: the button carries it, so a label the
        // strip has to truncate still reads in full on hover. (A second span used to hold
        // it, got no text, and left an empty box with its own styling behind.)
        el.title = typeof meta === "string" ? meta : (meta.title || meta.label || "");

        const isLink = typeof meta === "object" && meta !== null && !!meta.link;
        el.onclick = (e) => {
          if (!isLink) e.preventDefault();
          this.navigateTo(idx);
        };
        break;
      }

      case "@tab>menu>item>label":
        el.textContent = typeof payload === "string" ? payload : (!payload.value ? payload?.label : payload.value) || "";
        break;

      case "@tab>body": {
        payload.forEach((item: any, idx: number) => {
          const panel = this.render("@tab>panel", { item, idx }) as HTMLElement;
          el.appendChild(panel);
        });
        break;
      }

      case "@tab>panel": {
        const { item, idx } = payload;

        el.setAttribute("role", "tabpanel");
        el.setAttribute("aria-labelledby", this.buttonIdOf(idx));
        el.id = this.panelIdOf(idx);

        if (item?.className) el.classList.add(...String(item.className).split(" ").filter(Boolean));

        el.classList.add("hidden");
        el.style.display = "none";

        if (!this.config.lazyload) {
          this._renderPanelContent(el, item, idx);
        }
        break;
      }

      case "@tab>panel>content": {
        if (payload.eyebrow) {
          const span = this.render("@tab>panel>content>eyebrow", payload)!;
          el.appendChild(span);
        }
        if (payload.title) {
          const h3 = this.render("@tab>panel>content>title", payload)!;
          el.appendChild(h3);
        }
        if (payload.description) {
          const p = this.render("@tab>panel>content>desc", payload)!;
          el.appendChild(p);
        }
        break;
      }

      case "@tab>panel>content>eyebrow":
        el.textContent = payload?.eyebrow || "";
        break;

      case "@tab>panel>content>title":
        el.textContent = payload?.title || "";
        break;

      case "@tab>panel>content>desc":
        el.textContent = payload?.description || "";
        break;

      case "@tab>footer":
        if (payload?.id) el.id = payload.id;
        if (payload?.className) el.classList.add(...String(payload.className).split(" ").filter(Boolean));
        el.textContent = payload?.text || "";
        break;
    }
  }


  public initialize(): void {
    const menuElement = this.load("@tab>menu") as HTMLElement;

    if (menuElement) {
      this._boundKeyDownHandler = (e: KeyboardEvent) => this._handleKeyDown(e);
      menuElement.addEventListener("keydown", this._boundKeyDownHandler);
    }

    // Navigasi awal mengikuti `config.active`: indeks, id tombol, label, atau judul.
    // A target that matches nothing falls back to the first tab: a tab with no active
    // panel paints an empty box with no selected button.
    const start = this.resolve(this.config.active);
    this.navigateTo(start === -1 ? 0 : start);
    // console.log("[Tabs v2] Dynamic accessibility tab list initialized successfully.");
  }

  /**
   * Mengisi dan merender konten item ke dalam tab panel fisik
   */
  private _renderPanelContent(panel: HTMLElement, item: any, index: number): void {
    if (panel.dataset.loaded === "true") return;

    const content = item?.panel ? item.panel : item;

    if (content instanceof HTMLElement) {
      panel.append(content);
    } else {
      const contentWrapper = this.render("@tab>panel>content", content) as HTMLElement;
      panel.appendChild(contentWrapper);
    }

    panel.dataset.loaded = "true";
    this.config.emit?.("tabs:content-loaded" as any, { index, element: panel });
    for (const listener of this._listenersContentLoaded) listener({ index, element: panel });
  }

  public navigateTo(target: number | string): void {
    const targetIndex = this.resolve(target);

    // Gerbang Pengaman: Cegah eksekusi jika nomor indeks melompat di luar pagar batas array
    if (targetIndex < 0 || targetIndex >= this.#items.length) return;

    // Nyalakan boks spinner pemuat internal sesaat sebelum perpindahan wajah halaman dimulai
    const spinner = this.load("@tab>spinner") as HTMLElement;
    if (spinner) spinner.classList.remove("hidden");

    // Tembakkan eksekutor mutasi visual tunggal
    this._handleChange(targetIndex);

    // Berikan jeda mikro yang estetik agar efek transisi visual terasa sehalus sutra
    setTimeout(() => {
      if (spinner) spinner.classList.add("hidden");
    }, 150);
  }

  private _handleChange(index: number): void {
    // Jemput seluruh pasukan elemen hidup secara adil dan bersih menggunakan tanda "all"
    const buttons = this.buttons();
    const panels = this.panels();

    // ====================================================
    // 🫗 FASE 1: LIKUIDASI KONDISI AKTIF PADA TAB SEBELUMNYA
    // ====================================================
    if (buttons[this.currentTabIndex]) {
      const prevBtn = buttons[this.currentTabIndex];
      prevBtn.classList.remove("active"); // Gunakan standard token kelas active v2 Anda
      prevBtn.setAttribute("aria-selected", "false");
      prevBtn.setAttribute("tabindex", "-1");
    }

    if (panels[this.currentTabIndex]) {
      this.leave(panels[this.currentTabIndex]);
    }

    // ====================================================
    // 🌟 FASE 2: DETONASI NYALA PADA TAB BARU TUJUAN USER
    // ====================================================
    this.currentTabIndex = index;

    if (buttons[index]) {
      const activeBtn = buttons[index];
      activeBtn.classList.add("active");
      activeBtn.setAttribute("aria-selected", "true");
      activeBtn.setAttribute("tabindex", "0");

      // Fokuskan mata kursor jika user sedang menggunakan navigasi keyboard arrow keys
      if (document.activeElement && document.activeElement.parentElement === activeBtn.parentElement) {
        activeBtn.focus();
      }
    }

    if (panels[index]) {
      const activePanel = panels[index];

      // 🔮 LAZY-LOAD HYDRATION TRIGGER: Gambar isi rahim konten murni HANYA sesaat sebelum dibuka!
      if (this.config.lazyload) {
        this._renderPanelContent(activePanel as HTMLElement, this.#items[index], index);
      }

      activePanel.classList.remove("hidden");
      (activePanel as HTMLElement).style.display = "block";
    }

    // ====================================================
    // 📢 FASE 3: PIPELINE EMITTER GLOBAL KAYA INFORMASI
    // Semburkan event ke level luar lengkap dengan teks label dan judul tombolnya!
    // EMIT TIDAK LAGI DIGATE OLEH `buttons[index]`: pada inisialisasi awal
    // (navigateTo(0) dari initialize) menu bisa belum queryable/detached, sehingga
    // event tab:changed harus tetap dikirim agar listener init ikut menerimanya.
    // ====================================================
    if (this.config.emit && typeof this.config.emit === "function") {
      this.config.emit?.("elementChanged" as any, {
        builder: this.builderId,
        type: "tab:changed",
        data: { index, name: this.config.name },
        element: panels[index] || null
      });
    }

    // `onTabChanged` callbacks had no caller before: the change is the one moment they
    // describe, so they are fed here, in registration order.
    if (this._listenersTabChanged.length) {
      const button = buttons[index];
      const detail = {
        index,
        label: button?.querySelector(".btn-label")?.textContent ?? "",
        title: button?.title ?? "",
      };
      for (const listener of this._listenersTabChanged) listener(detail);
    }
  }

  /** `animation: false` disables panel motion, `true` keeps the default fade, and an object
   *  carries `@keyframes` names the sheet reads through two custom properties. */
  private applyAnimation(root: HTMLElement): void {
    const animation = this.config.animation;
    if (animation === false) {
      root.dataset.animation = "none";
      return;
    }
    if (animation && typeof animation === "object") {
      root.dataset.animation = "custom";
      if (animation.in) root.style.setProperty("--tab-anim-in", animation.in);
      if (animation.out) root.style.setProperty("--tab-anim-out", animation.out);
    }
  }

  /** The id one menu item carries: its own when the record names one, else the instance
   *  stem plus its index. A panel points its `aria-labelledby` at exactly this. */
  private buttonIdOf(index: number): string {
    const meta = this.#menu[index] as { id?: string } | undefined;
    return meta?.id || `tabbtn-${this.uid}-${index}`;
  }

  /** The id one panel carries, and the value its button's `aria-controls` names. */
  private panelIdOf(index: number): string {
    const item = this.#items[index] as { id?: string } | undefined;
    return item?.id || `tabpanel-${this.uid}-${index}`;
  }

  /**
   * This instance's menu items — direct children of its own menu, never descendants.
   *
   * A nested tab renders its menu inside this tab's panel; a descendant query would put
   * the child's buttons into the parent's list and clicking a child tab would move the
   * parent.
   */
  private buttons(): HTMLElement[] {
    const menu = this.load("@tab>menu");
    if (!menu) return [];
    return Array.from(menu.children).filter(
      (child): child is HTMLElement =>
        child instanceof HTMLElement && child.getAttribute("role") === "tab",
    );
  }

  /**
   * This instance's panels — direct children of its own body, never descendants.
   *
   * Same trap as `buttons()`: `querySelectorAll(".panel")` also collects every panel of
   * a tab nested in a panel, so index 1 of a two-tab parent pointed at the child's first
   * panel and the parent's own second panel never opened.
   */
  private panels(): HTMLElement[] {
    const body = this.load("@tab>body");
    if (!body) return [];
    return Array.from(body.children).filter(
      (child): child is HTMLElement =>
        child instanceof HTMLElement && child.classList.contains("panel"),
    );
  }

  /** A number is an index; a string is matched against the button id, the panel it controls,
   *  then its label and title — so `active` accepts whichever the caller already has. */
  private resolve(target: number | string): number {
    if (typeof target === "number") return target;
    const buttons = this.buttons();
    for (let i = 0; i < buttons.length; i += 1) {
      const button = buttons[i];
      if (
        button.id === target ||
        button.getAttribute("aria-controls") === target ||
        button.querySelector(".btn-label")?.textContent === target ||
        button.title === target
      ) {
        return i;
      }
    }
    return -1;
  }

  /** Hide the panel we just left. With `destroyPrevious` its content is wiped — but only
   *  after the `out` animation ends, so the wipe never reads as a jump. */
  private leave(panel: HTMLElement): void {
    const hide = (): void => {
      panel.classList.add("hidden");
      panel.style.display = "none";
    };

    const wipe = (): void => {
      panel.replaceChildren();
      panel.dataset.loaded = "false";
    };

    if (!this.config.destroyPrevious) {
      hide();
      return;
    }

    if (!this.config.animation) {
      wipe();
      hide();
      return;
    }

    let settled = false;
    const finish = (): void => {
      if (settled) return;
      settled = true;
      panel.removeEventListener("animationend", finish);
      panel.classList.remove("is-leaving");
      wipe();
      hide();
    };

    panel.classList.add("is-leaving");
    panel.addEventListener("animationend", finish);
    // A keyframe that never resolves leaves no `animationend`; never strand the panel.
    setTimeout(finish, 700);
  }

  private _handleKeyDown(e: KeyboardEvent): void {
    const buttons = this.buttons();
    if (!buttons || !buttons.length) return;
    let nextIndex = this.currentTabIndex;
    const isHorizontal = this.config.menuPosition === "top" || this.config.menuPosition === "bottom";
    if (isHorizontal) {
      if (e.key === "ArrowRight") nextIndex = (this.currentTabIndex + 1) % buttons.length;
      else if (e.key === "ArrowLeft") nextIndex = (this.currentTabIndex - 1 + buttons.length) % buttons.length;
      else if (e.key === "Home") nextIndex = 0; else if (e.key === "End") nextIndex = buttons.length - 1;
      else return; // Abaikan tombol keyboard lain
    } else {
      // Kondisi orientasi menu vertikal (left / right)
      if (e.key === "ArrowDown") nextIndex = (this.currentTabIndex + 1) % buttons.length;
      else if (e.key === "ArrowUp") nextIndex = (this.currentTabIndex - 1 + buttons.length) % buttons.length;
      else if (e.key === "Home") nextIndex = 0; else if (e.key === "End") nextIndex = buttons.length - 1;
      else return;
    }
    e.preventDefault();
    this.navigateTo(nextIndex);
    // Paksa fokus keyboard melompat ke elemen tombol aktif yang baru
    (buttons[nextIndex] as HTMLElement).focus();
  }

  public onTabChanged(callback: (detail: { index: number; label: string; title: string }) => void): void {
    if (typeof callback === "function") this._listenersTabChanged.push(callback);
  }

  public onContentLoaded(callback: (detail: { index: number; element: HTMLElement }) => void): void {
    if (typeof callback === "function") this._listenersContentLoaded.push(callback);
  }

  public unmount(): void {
    const menuElement = this.load("@tab>menu") as HTMLElement;
    if (menuElement && this._boundKeyDownHandler) {
      menuElement.removeEventListener("keydown", this._boundKeyDownHandler);
    }
    // Callbacks belong to the instance; a destroyed tab must not keep them alive.
    this._listenersTabChanged.length = 0;
    this._listenersContentLoaded.length = 0;
    this.destroy(); // Likuidasi total RAM dari rahim Map privat!
  }

}
